import socket
import threading
from sys import argv, exit


def get_args(recurred=False):
    try:
        if len(argv) == 3 and not recurred:
            ipAddress = argv[1]
            portNum = int(argv[2])
        elif len(argv) > 1 and not recurred:
            raise ValueError
        else:
            ipAddress = input("Enter server IP address:\n")
            print(ipAddress)
            portNum = int(input("Enter the port number:\n"))
            print(portNum)
        return (ipAddress, portNum)
    except ValueError:
        if len(argv) > 1 and not recurred:
            print("Invalid command line arguments.")
        print("Please enter a valid IP address and port number below.")
        return get_args(recurred=True)


ipAddress, portNum = get_args()

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    client.connect((ipAddress, portNum))
except ConnectionRefusedError:
    print("Connection refused. Make sure the server is running and that the port number is correct.")

nickname = input("Choose your nickname: ")

# flag to signal threads to stop
stop_threads = False


def receive():
    global stop_threads
    while not stop_threads:
        try:
            message = client.recv(1024).decode('ascii')
            if message == 'NICK':
                client.send(nickname.encode('ascii'))
            else:
                print(message)
        except:
            print("An error occured!")
            client.close()
            break


def write():
    global stop_threads
    while True:
        if not stop_threads:
            clientInput = input("/all to broadcast, \n/whisper [nickname] for private, \n" +
                                "/list to view online clients, \n/hide to hide presence, \n/unhide to unhide connection, \n" +
                                "/end to leave server: \n")

            if stop_threads:
                break

            partsOfInput = clientInput.strip().split(maxsplit=1)
            command = partsOfInput[0]
            args = partsOfInput[1].strip() if len(partsOfInput) > 1 else ''

            commands = {
                "/all": broadcastToAll,  # broadcast message
                "/list": listOnlineClients,  # request list of online clients,
                "/whisper": privateMessage,  # private message
                "/hide": hideConnection,  # hide presence,
                "/unhide": unhideConnection,
                "/end": exitServer,  # leave server
            }

            if command in commands:
                commands[command](args)
            else:
                print("invalid input!")


def broadcastToAll(message):
    formattdMessage = '{}: {}'.format(nickname, message)
    client.send(formattdMessage.encode('ascii'))


def listOnlineClients(args):
    client.send("/list".encode('ascii'))


def privateMessage(recip):
    while recip == '' or recip == " ":
        recip = input("Enter nickname of recipient: ")
    message = input("Type a message: ")
    formattedMessage = '/whisper {} {} {}'.format(nickname, recip, message)
    client.send(formattedMessage.encode('ascii'))


def hideConnection(args):
    client.send("/hide".encode('ascii'))


def unhideConnection(args):
    client.send("/unhide".encode('ascii'))


def exitServer(args):
    global stop_threads
    client.send("/end".encode('ascii'))
    stop_threads = True
    client.close()
    print("Connection closed.")


def main():
    receive_thread = threading.Thread(target=receive, daemon=True)
    receive_thread.start()

    # print("Receive thread started")

    write_thread = threading.Thread(target=write, daemon=True)
    write_thread.start()

    while not stop_threads:
        pass

    exit(0)

    # print("Write thread started")


if __name__ == "__main__":
    main()
