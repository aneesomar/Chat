import socket
import threading

host = '127.0.0.1'
port = 1364

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((host, port))
server.listen()
print("Server Started...")

clients = []
nicknames = []
unhiddenClientsNick = []


def broadcast(message):
    for client in clients:
        client.send(message)


def list_clients():
    if nicknames:
        return "Connected clients: " + ", ".join(nicknames)
    else:
        return "No clients connected."


def listOnlineClients():
    if unhiddenClientsNick:
        return "Connected clients: " + ", ".join(unhiddenClientsNick)
    else:
        return "No clients connected."


def handle(client):
    while True:
        try:
            message = client.recv(1024).decode('ascii')

            if message == '/end':
                client.send("Connection closed.".encode('ascii'))
                index = clients.index(client)
                clients.remove(client)
                nick = nicknames[index]
                if nick in unhiddenClientsNick:
                    unhiddenClientsNick.remove(nick)
                    broadcast("{} left the server.".format(
                        nick).encode('ascii'))
                nicknames.remove(nick)
                client.close()
                break

            elif message == '/list':
                client.send(listOnlineClients().encode('ascii'))

            elif message.startswith("/whisper"):
                parts = message.split(maxsplit=3)

                sender = parts[1]
                recip = parts[2]
                msgToSend = parts[3]

                privateMessage(sender, recip, msgToSend)

            elif message == '/hide':
                for client, nickname in zip(clients, nicknames):
                    if nickname in unhiddenClientsNick:
                        unhiddenClientsNick.remove(nickname)
                        client.send(
                            "Your connection is hidden from other users.".encode('ascii'))
                        broadcast("{} left the server.".format(
                            nickname).encode('ascii'))
                    else:
                        client.send(
                            "Your connection is already hidden from other users.".encode('ascii'))

            elif message == '/unhide':
                for client, nickname in zip(clients, nicknames):
                    if nickname in unhiddenClientsNick:
                        client.send(
                            "Your connection is already available to other users.".encode('ascii'))
                    else:
                        client.send(
                            "Your connection is now available to other users.".encode('ascii'))
                        unhiddenClientsNick.append(nickname)
                        broadcast("{} joined the server.".format(
                            nickname).encode('ascii'))

            else:
                broadcast(message.encode('ascii'))
        except:
            index = clients.index(client)
            clients.remove(client)
            client.close()
            nickname = nicknames[index]
            broadcast('{} left the server.'.format(nickname).encode('ascii'))
            nicknames.remove(nickname)
            break


def privateMessage(sender, recipient, message):
    recipClient = findRecipient(recipient)
    if recipClient:
        formattedMsg = "{} -> {}: {}".format(sender, recipClient, message)
        recipClient.send(formattedMsg.encode('ascii'))
    else:
        sender.send("Unable to find recipient :/".encode('ascii'))


def findRecipient(recipNick):  # find recipient to priv msg
    for client, nickname in zip(clients, nicknames):
        if nickname == recipNick:
            return client
    return None


def receive():
    while True:
        client, address = server.accept()
        print("Connected with {}".format(str(address)))

        client.send('NICK'.encode('ascii'))
        nickname = client.recv(1024).decode('ascii')
        nicknames.append(nickname)
        clients.append(client)
        unhiddenClientsNick.append(nickname)

        print("Nickname is {}".format(nickname))
        broadcast("{} joined the server.".format(nickname).encode('ascii'))
        client.send(
            'Connected to server!\nType /help for list of commands'.encode('ascii'))

        thread = threading.Thread(target=handle, args=(client,))
        thread.start()


receive()
